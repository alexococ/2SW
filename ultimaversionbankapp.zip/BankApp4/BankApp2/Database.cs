using System;
using System.Data;
using Microsoft.Data.Sqlite;

public class Database
{
    private string connectionString;

    // Constructor que recibe la ruta del archivo de la base de datos
    public void fileDatabase(string dbFilePath){
        connectionString = $"Data Source={dbFilePath}";
    }

    // Método para crear una tabla en la base de datos
    
    public void CrearTablaConDatos(string sName, string sAddress, string sPhone, string sMoney )
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (SqliteCommand command = new SqliteCommand())
            {
                int iMoney = int.Parse(sMoney);
                command.Connection = connection;

                // Define la consulta SQL para crear la tabla
                command.CommandText = "CREATE TABLE IF NOT EXISTS Personas (Name TEXT, Address TEXT, PhoneNumber TEXT, CurrentMoney REAL)";
                command.ExecuteNonQuery();

                // Después de crear la tabla, inserta datos en los campos
                command.CommandText = "INSERT INTO Personas (Name, Address, PhoneNumber, CurrentMoney) VALUES (@Name, @Address, @PhoneNumber, @CurrentMoney)";
                command.Parameters.AddWithValue("@Name", sName);
                command.Parameters.AddWithValue("@Address", sAddress);
                command.Parameters.AddWithValue("@PhoneNumber", sPhone);
                command.Parameters.AddWithValue("@CurrentMoney", iMoney);
                command.ExecuteNonQuery();
            }

            connection.Close();
        }
    }


    // Método para actualizar un campo en la tabla
    public void ActualizarCampo(string nombre, string campo, object nuevoValor)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open(); // Abrir la conexión

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection; // Asignar la conexión al comando

                // Definir la consulta SQL para actualizar un campo
                command.CommandText = $"UPDATE Personas SET {campo} = $NuevoValor WHERE Name = $Nombre";
                command.Parameters.AddWithValue("$Nombre", nombre); // Parámetro para el nombre
                command.Parameters.AddWithValue("$NuevoValor", nuevoValor); // Parámetro para el nuevo valor

                command.ExecuteNonQuery(); // Ejecutar la consulta
            }

            connection.Close(); // Cerrar la conexión
        }
    }

    // Método para obtener el valor de un campo en la tabla
   public T ObtenerCampo<T>(string nombre, string campo)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection;
                command.CommandText = $"SELECT {campo} FROM Personas WHERE Name = $Nombre";
                command.Parameters.AddWithValue("$Nombre", nombre);

                object resultado = command.ExecuteScalar();

                if (resultado != DBNull.Value)
                {
                    return (T)Convert.ChangeType(resultado, typeof(T));
                }

                return default(T);
            }
        }
    }


    public bool VerificarExistenciaTablaPorNombre(string nombre)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection;
                command.CommandText = "SELECT Name FROM sqlite_master WHERE type='table' AND Name=@Nombre";
                command.Parameters.AddWithValue("@Nombre", nombre);

                using (SqliteDataReader reader = command.ExecuteReader())
                {
                    return reader.HasRows;
                }
            }
        }
    }



}
