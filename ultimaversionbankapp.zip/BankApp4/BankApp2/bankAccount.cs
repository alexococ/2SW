namespace bankApp{
    public class bankAccounts  {
        private string? idAccount { get; set;}
        private string? ownerAccount { get; set;}
        private float amountAccount { get; set;}

        //Constructor
        /*
        public bankAccounts(string owner , string id, float amount){
            this.amountAccount = amount;
            this.idAccount = id;
            this.ownerAccount = owner;
        }*/
        //Métodos get
        
        public string GetFullDetails(){ //Da todos los detalles de la cuenta
            return $"El propietario de la cuenta es {ownerAccount}, tiene {amountAccount} y su referencia es {idAccount}";
        }

        public float getAmount(){
            return amountAccount;
        }

        public string getIdAccount(){
            return idAccount;
        }

        public string getNameOwner(){
            return ownerAccount;
        }

        //Métodos set

        public void setAmount(float newAmount){
            this.amountAccount = newAmount;
        }
        public void setNameOwner(string newOwner){
            this.ownerAccount = newOwner;
        }

        public void setIdAccount(string newId){
            this.idAccount = newId;
        }

    }
}
 