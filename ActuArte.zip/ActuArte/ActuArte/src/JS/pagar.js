let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
});



function guardarDatos() {
    const phone = document.getElementById("phoneInput").value;
    const email = document.getElementById("emailInput").value;
    const name = document.getElementById("nameInput").value;
    const documentType = document.getElementById("documentTypeInput").value;

    const datos = {
        phone: phone,
        email: email,
        name: name,
        documentType: documentType,
    };

    // Crea un nuevo elemento div para el contenido del PDF
    const pdfContent = document.createElement('div');

    // Agrega la información del usuario al contenido del PDF
    pdfContent.innerHTML = `
        <p><strong>NOMBRE DE RESERVA:</strong> ${name}</p>
        <p><strong>MOVIL:</strong> ${phone}</p>
        <p><strong>CORREO ELECTRÓNICO:</strong> ${email}</p>
        <p><strong>NOMBRE DEL TITULAR:</strong> ${name}</p>
        <p><strong>TIPO DE DOCUMENTO:</strong> ${documentType}</p>
    `;

    // Opciones para html2pdf
    const options = {
        margin: 10,
        filename: 'Datos_Reserva.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    // Convierte el contenido del PDF en un archivo PDF
    html2pdf(pdfContent, options);

    console.log('Datos guardados y PDF descargado:', datos);





    document.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        const tituloObra = decodeURIComponent(urlParams.get('obra'));
        const totalPagar = urlParams.get('total');

        if (tituloObra) {
            document.querySelector('.title.o-5').textContent = tituloObra;
        }

        if (totalPagar) {
            document.querySelector('.summa').textContent = `${totalPagar} $`;
        }
    });
}
