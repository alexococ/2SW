let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})