document.addEventListener('DOMContentLoaded', () => {
    const seatContainer = document.getElementById('seatContainer');
    const countSpan = document.getElementById('count');
    const totalSpan = document.getElementById('total');
    const reserveButton = document.getElementById('reserve-button');
    const rows = 8;
    const seatsPerRow = 20;
    let selectedSeats = [];


    const occupiedSeats = JSON.parse(localStorage.getItem('occupiedSeats')) || [];


    for (let i = 0; i < rows; i++) {
        const rowElement = document.createElement('div');
        rowElement.classList.add('row');

        for (let j = 0; j < seatsPerRow; j++) {
            const seatIndex = i * seatsPerRow + j;
            const seatElement = document.createElement('div');
            seatElement.classList.add('seat');
            seatElement.setAttribute('data-seat-index', seatIndex);

           
            if (occupiedSeats.includes(seatIndex)) {
                seatElement.classList.add('occupied');
            } else {
                
                seatElement.addEventListener('click', () => {
                    toggleSeatStatus(seatElement, i, j + 1);
                });
            }

            rowElement.appendChild(seatElement);
        }

        seatContainer.appendChild(rowElement);
    }

    function toggleSeatStatus(seat, row, number) {
        if (!seat.classList.contains('occupied')) {
            seat.classList.toggle('selected');
            updateSelectedCount();
            seat.style.backgroundColor = seat.classList.contains('selected') ? '#f1d791' : '';
        }
    }

    function updateSelectedCount() {
        selectedSeats = document.querySelectorAll('.row .seat.selected');
        const selectedSeatsCount = selectedSeats.length;
        countSpan.innerText = selectedSeatsCount;
        totalSpan.innerText = selectedSeatsCount * 10;
    }

    reserveButton.addEventListener('click', () => {
        const selectedSeatIndexes = [...document.querySelectorAll('.seat.selected')].map(seat => parseInt(seat.getAttribute('data-seat-index'), 10));

        
        fetch('/api/reservar-asientos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ seats: selectedSeatIndexes })
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                selectedSeatIndexes.forEach(index => {
                    if (!occupiedSeats.includes(index)) {
                        occupiedSeats.push(index);
                        const seat = document.querySelector(`[data-seat-index='${index}']`);
                        if (seat) {
                            seat.classList.remove('selected');
                            seat.classList.add('occupied');
                            seat.style.backgroundColor = '#5e0a0f';
                        }
                    }
                });

                // Guardar los asientos ocupados en localStorage
                localStorage.setItem('occupiedSeats', JSON.stringify(occupiedSeats));
                updateSelectedCount(); // Actualizar conteo a 0
                alert(`Has comprado esta obra: ${document.getElementById('obraTitulo').innerText}`);
            })
            .catch(error => console.error('Error:', error));
    });

});


// TITULO DE LA OBRA OBTENIDA DE DETALLES.
document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));
    if (tituloObra) {
        document.getElementById('obraTitulo').textContent = tituloObra;
    }
});



document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tituloObra = decodeURIComponent(urlParams.get('obra'));

    const totalPagar = document.getElementById('totalPagar').textContent;

    const enlaceReservar = document.getElementById('enlaceReservar');
    enlaceReservar.href = `pagar.html?obra=${encodeURIComponent(tituloObra)}&total=${encodeURIComponent(totalPagar)}`;
});
