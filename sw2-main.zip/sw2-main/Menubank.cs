using System.Formats.Asn1;
using System.Threading.Tasks.Dataflow;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace bankApp
{
    public class MenuBank
    {


        public bool Finalise { get; set; }
        //get de las variables
      
        public bool getFinalise()
        {
            return Finalise;
        }

        public void setFinalise(bool s)
        {
            this.Finalise = s;
        }

        //Menú de la consola
        public int MenuConsola()
        {//Menú incial
            Console.WriteLine("Hola, Bienvenido a SvBank");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Tiene diferentes opciones: (pulse el número correspodiente)");
            Console.WriteLine("1 Crear una cuenta");
            Console.WriteLine("2 Entrar en una cuenta");
            string sNumber = Console.ReadLine();
            //int option = int.Parse(sNumber);
            if (!int.TryParse(sNumber, out int number) || number < 1 || number > 2)
            {//si lo mete mal repite
                Console.WriteLine("Lo siento, lo has introducido mal, tienes que introducir 1 o 2");
                MenuConsola();
            }
            return number;
        }

       
        public void opcionesGestionar()
        {//Menú dentro de gestionar cuenta
            bankTransactions bTrans = new bankTransactions();
            bankAccounts bAccount = new bankAccounts();

            Console.WriteLine("Has entrado en gestionar cuenta, ¿Qué quieres hacer?");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("1 Para cambiar los datos de la cuenta");
            Console.WriteLine("2 Para ingresar dinero");
            Console.WriteLine("3 Para sacar dinero");
            Console.WriteLine("4 Para hacer una transferencias");
            Console.WriteLine("5 Para ver los últimos moviemientos de la cuenta");
            int iOption = Convert.ToInt32(Console.ReadLine());
            
            switch (iOption)
            {
                case 1: { bAccount.changeDetailsAccount(); break; }
                case 2: { bTrans.makeDeposit(); break; }
                case 3: { bTrans.withdrawMoney(); break; }
                case 4: { bTrans.makeTransfer(); break; }
                case 5: { bAccount.seeMovements(); break;}
                default:{
                            Console.WriteLine("Lo has introducido mal, tienes que poner del 1 al 5");
                            opcionesGestionar();
                            break;
                        }
            }
        }


        
    
        public void gestionarSalir()
        {//Menú para seguir gestionando o salir
            bankTransactions bTrans = new bankTransactions();
            bankAccounts bAccount = new bankAccounts();

            Console.WriteLine("¿Que quieres hacer?");
            Console.WriteLine("-------------------");
            Console.WriteLine("1 Para seguir gestionando o 2 para salir");
            int option = Convert.ToInt32(Console.ReadLine());
            
            switch(option){
                case 1:{opcionesGestionar(); break;}
                case 2:
                {
                    setFinalise(true);
                    Console.WriteLine("Has terminado las operaciones");
                    break;
                }
                default:
                {
                    while(option != 1 || option != 2){
                        Console.WriteLine("Lo has introducido mal, tienes que introducir 1 para seguir gestionando o 2 para salir");
                        option = Convert.ToInt32(Console.ReadLine());        
                    }
                    switch(option){
                        case 1:{opcionesGestionar(); break;}
                        case 2:
                        {
                            setFinalise(true);
                            Console.WriteLine("Has termiando las operaciones");
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }
}