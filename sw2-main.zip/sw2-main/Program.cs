﻿﻿// See https://aka.ms/new-console-template for more information
using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Text.Json.Serialization;
using bankApp;




internal class Program
{
    private static void Main(string[] args)
    {
        bankAccounts bAccount = new bankAccounts();
        bankTransactions btrans = new bankTransactions();
        MenuBank menuB = new MenuBank();

        while (menuB.getFinalise() != true)
        {

            int option = menuB.MenuConsola();
            if (option == 1)//Crear cuenta
            {
                bAccount.createAccount();//Introduce la información.
                                                //Crea la tabla con los datos.

                Console.WriteLine("¿Quieres empezar a gestionar la cuenta o salir?");
                Console.WriteLine("-----------------------------------------------");
                Console.WriteLine("Escribe 1 para gestionar la cuenta o 2 para salir");
                int iGestionaroSalir = Convert.ToInt32(Console.ReadLine());
                if (iGestionaroSalir == 1)
                {
                    bAccount.comprobationName();
                    menuB.opcionesGestionar();

                }
                else if (iGestionaroSalir == 2)
                {
                    menuB.setFinalise(true);
                    Console.WriteLine("Has salido existosamente!!!!");
                }
            }
            if (option == 2)
            {//Gestionar cuenta
                bAccount.comprobationName();
                menuB.opcionesGestionar();
            }
        }
    }
}