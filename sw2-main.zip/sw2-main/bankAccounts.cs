using System.ComponentModel.DataAnnotations.Schema;
using System.Dynamic;
using System.IO;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
namespace bankApp
{
    public class bankAccounts
    {
        
        public string clientName { get; set; }
        public string ClientDirection { get; set; }
        public string ClientPhoneNumber { get; set; }
        public string ClientCurrentMoney { get; set; }
        public List<string> listaTransacciones {get; set;}= new List<string>();        
        public List<bankAccounts> userDetails {get; set;} = new List<bankAccounts>();
        
        //Métodos get

        public string getClientName()
        {
            return this.clientName;
        }

        public void setClientName(string name){
            this.clientName = name;
        }

        public string getClientDirection()
        {
            return this.ClientDirection;
        }
        public string getClientPhone()
        {
            return this.ClientPhoneNumber;
        }

        public string getClientMoney()
        {
            return this.ClientCurrentMoney;
        }

        public List<bankAccounts> getList(){
            return userDetails;
        }

        public string asignarRuta(string nameRuta){
            string directorioBase = AppDomain.CurrentDomain.BaseDirectory;
            string nameruth = Path.Combine(directorioBase, nameRuta);
            return nameruth;
        }

        public void seeMovements(){
            bankAccounts cliente = searchInfoClient(clientName);
            Console.WriteLine("Tus Movimeitos son estos:");
            Console.WriteLine("----------------------------");
            int contador = 1;
            foreach(string elemento in cliente.listaTransacciones){
                Console.WriteLine( contador + " " + elemento);
                contador++;
            } 
        }

        public void createAccount()
        {
            Console.WriteLine("Vamos a proceder a rellenar los datos para crear la cuenta");
            Console.WriteLine("-----------------------------------------------------------");

            Console.WriteLine("Introduce el nombre y apellidos");
            this.clientName = Console.ReadLine();

            Console.WriteLine("Introduce tu dirección");
            this.ClientDirection = Console.ReadLine();

            Console.WriteLine("Introduce tu número de teléfono");
            this.ClientPhoneNumber = Console.ReadLine();


            Console.WriteLine("Para terminar, introduce la cantidad con la que quieres iniciar tu cuenta");
            this.ClientCurrentMoney = Console.ReadLine();
            
            List<string> registro = new List<string>();
            registro.Add("Se ha creado la cuenta a las "+ DateTime.Now.ToString());
            insertData(clientName,ClientDirection, ClientPhoneNumber, ClientCurrentMoney, registro);
        }

        public void comprobationName()
        {//Menú que pide el nombre después de entrar en la opción de gestionar cuenta
            MenuBank menuAccount = new MenuBank();
            Console.WriteLine("Has entrado en la opción de gestionar cuenta, ¿Qué deseas hacer?");
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("Pon tu nombre y apellidos para entrar en tu cuenta");
            setClientName(Console.ReadLine());
            bankAccounts nombreCliente = searchInfoClient(clientName);
            if(nombreCliente == null){
                Console.WriteLine("Lo siento, no hemos encontrado ese nombre en nuestra base de datos");
                Console.WriteLine("------------------------------------------------------------------");
                Console.WriteLine("1 para crear una cuenta");
                Console.WriteLine("2 Para intentar introducir en nombre de nuevo");
                Console.WriteLine("3 Para terminar la consulta");
                int option = Convert.ToInt32(Console.ReadLine());

                switch(option){
                    case 1: {createAccount(); break;}
                    case 2: {comprobationName(); break;}
                    case 3: {menuAccount.setFinalise(true);  Console.WriteLine("El programa ha terminado"); break;}
                    default:{
                                while(option < 1 || option > 3){
                                    Console.WriteLine("Introduce de nuevo el número porfavor");
                                    Console.WriteLine("1 para crear una cuenta");
                                    Console.WriteLine("2 Para intentar introducir en nombre de nuevo");
                                    Console.WriteLine("3 Para terminar la consulta");
                                    option = Convert.ToInt32(Console.ReadLine());            
                                }
                                switch(option){
                                    case 1: {createAccount(); break;}
                                    case 2: {comprobationName(); break;}
                                    case 3: {menuAccount.setFinalise(true);  Console.WriteLine("El programa ha terminado"); break;}                    
                                }
                                break;
                            }
                }
            }
            Console.WriteLine("Has entrado!!!");
        }

        public void changeDetailsAccount()
        {
            Console.WriteLine("Has elegido cambiar los datos de la cuenta");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("¿Qué quieres cambiar?");
            Console.WriteLine("--------------------");
            Console.WriteLine("1 El nombre del dueño de la cuenta");
            Console.WriteLine("2 La dirección");
            Console.WriteLine("3 El número de teléfono");
            int iOptionChangeDetails = Convert.ToInt32(Console.ReadLine());

            bankAccounts client = searchInfoClient(clientName);
            MenuBank menuAccount = new MenuBank();
       
            switch (iOptionChangeDetails)
            {//Cambiar algunos datos por campo
                case 1:
                    {//Cambiar el nombre 
                        Console.WriteLine("¿Cuál es el nuevo nombre?");
                        client.clientName = Console.ReadLine();
                        client.listaTransacciones.Add("Se ha cambiado el nombre de la cuenta a " + client.clientName);
                        
                        string jsonofClients = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                        File.WriteAllText(asignarRuta("database.json"), jsonofClients);
                        
                        Console.WriteLine("El nombre se ha cambiado correctamente");
                        
                        
                        break;
                    }
                case 2:
                    {//Cambiar la dirección 
                        Console.WriteLine("¿Cuál es la nueva dirección?");
                        client.ClientDirection = Console.ReadLine();
                        client.listaTransacciones.Add("Se ha cambiado la dirección de la cuenta a " + client.ClientDirection);
                        
                        string jsonofClients = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                        File.WriteAllText(asignarRuta("database.json"), jsonofClients);
                        
                        Console.WriteLine("La dirección se ha cambiado correctamente");
                    
                        break;
                    }
                case 3:
                    {//Cambiar el número de teléfono 
                        Console.WriteLine("¿Cuál es el nuevo número de teléfono?");
                        client.ClientPhoneNumber = Console.ReadLine();
                        client.listaTransacciones.Add("Se ha cambiado el número de teléfono de la cuenta a " + client.ClientPhoneNumber);    
                        
                        string jsonofClients = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                        File.WriteAllText(asignarRuta("database.json"), jsonofClients);
                        
                        Console.WriteLine("Se ha cambiado correctamente");
                        
                        break;
                    }
                default:
                    {
                        while(iOptionChangeDetails < 1 || iOptionChangeDetails > 3){
                            Console.WriteLine("Lo siento, te has equivocado al introducir la opción!");
                            Console.WriteLine("1 Para volver a intentar cambiar los datos de la cuenta");
                            Console.WriteLine("2 Para volver al menú para gestionar la cuenta");
                            Console.WriteLine("3 Para terminar la operación");
                            iOptionChangeDetails = Convert.ToInt32(Console.ReadLine());    
                        }

                        switch(iOptionChangeDetails){
                            case 1: {changeDetailsAccount(); break;}
                            case 2: {menuAccount.opcionesGestionar(); break;}
                            case 3: { menuAccount.setFinalise(true); 
                                      Console.WriteLine("Has termiando la operación");    
                                      break; 
                                    }
                        }
                        break;
                    }
            }
            Console.WriteLine("Los cambios se han hecho exitosamente.");
            menuAccount.gestionarSalir();
        }

        public void insertData(string nombre, string adress, string phoneNumber, string money,List<string> lista)
        {
            var userData = new bankAccounts()
            {
                clientName = nombre,
                ClientDirection = adress,
                ClientPhoneNumber = phoneNumber,
                ClientCurrentMoney = money,
                listaTransacciones = lista
            };
            
            string archivo = File.ReadAllText(asignarRuta("database.json"));
            userDetails = JsonConvert.DeserializeObject<List<bankAccounts>>(archivo);
            userDetails.Add(userData);
            string jsonClientes = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
            File.WriteAllText(asignarRuta("database.json"), jsonClientes);
            Console.WriteLine("La información se ha guardado exitosamente!");     
        }

        public bankAccounts searchInfoClient(string nombre)
        {
            string archivo = File.ReadAllText(asignarRuta("database.json"));
            userDetails = JsonConvert.DeserializeObject<List<bankAccounts>>(archivo);
            return userDetails.Find(cliente => cliente.clientName == nombre);
        }    
    }
}
