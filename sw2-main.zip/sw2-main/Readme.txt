Datos de acceso a Docker:
----------------------------------
Dvniiel // Contraseña de chatgpt


FROM mcr.microsoft.com/dotnet/sdk:7.0
WORKDIR /src
COPY . ./
RUN dotnet publish -c Release -o /app
ENTRYPOINT ["dotnet", "MyBankApp.dll"]




/* --------------------------------------   PASOS PARA CONTENERIZAR UN PROYECTO Y SUBIRLO A DOCKERHUB -------------------------------------- */


1) CREAR O LOGEARTE EN TU CUENTA Y ABRIR DOCKER DESKTOP.

2) ETIQUETAR TU IMAGEN EN DOCKER --> docker build -t dvniiel/mybankapp

3) VERIFICAR QUE LA IMAGEN SE HAYA CREADO CORRECTAMENTE --> docker images

4) INICIA SESIÓN EN DOCKERHUB DESDE LA LINEA DE COMANDOS --> docker login

5) SUBIR LA IMAGEN A DOCKERHUB --> docker push dvniiel/mybankapp

6) COMPARTIR TU IMAGEN UTILIZANDO ESTE FORMATO : dvniiel/mybankapp






/* --------------------------------------  PARA QUE LA USEN LOS COMPAÑEROS -------------------------------------- */


1) DESCARGAR LA IMAGEN DESDE DOCKERHUB --> docker pull dvniiel/mybankapp

2) EJECUTAR EL CONTENEDOR BASADO EN MI IMAGEN --> docker run -p 8080:80 dvniiel/mybankapp

3) ESTO INICIARÁ UN CONTENEDOR UTILIZANDO LA IMAGEN "dvniiel/mybankapp". LA OPCIÓN "-p 8080:80 MAPEA EL PUERTO
8080 DEL HOST LOCAL AL PUERTO 80 DEL CONTENEDOR, AHORA PODRÁN ACCEDER A LA APLICACIÓN DESDE SU NAVEGADOR WEB UTILIZANDO
LA URL --> "http://localhost:8080"

4) LOS COMPAÑEROS DEBEN DE TENER DOCKER INSTALADO Y ABIERTO











VERSION DE SDK PARA DOTNET : 7.0.403






