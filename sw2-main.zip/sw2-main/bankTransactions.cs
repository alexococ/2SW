using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Xml.Linq;
using bankApp;
using Newtonsoft.Json;
namespace bankApp
{

    public class bankTransactions
    {
     

        //Constructor

        //Método get

       
        public void makeDeposit() //case 2 menuOption3
        {
            
            MenuBank menuTrans = new MenuBank();
            Console.WriteLine("Has entrado en hacer un ingreso");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                menuTrans.opcionesGestionar();
            }
            else
            {//Seguir con la transferencia
                Console.WriteLine("¿De cuanto quieres hacer el ingreso?");
                int iTransferDeposit = Convert.ToInt32(Console.ReadLine());
                if (iTransferDeposit < 1)
                {//Para que meta una cantidad positiva
                    Console.WriteLine("Has introducido un número negativo, no puedes poner menos de 1");
                    while (iTransferDeposit < 1)
                    {
                        Console.WriteLine("Prueba otra vez");
                        iTransferDeposit = Convert.ToInt32(Console.ReadLine());
                    }
                }
                checkDestinataryDeposit(iTransferDeposit);//Hace el ingreso
                menuTrans.gestionarSalir();
            }
        }

        public void checkDestinataryDeposit(int i)
        {//comprueba que el destinatario existe para hacer el ingreso
            
            bankAccounts transAccount = new bankAccounts();
            Console.WriteLine("A quién quieres hacer el ingreso?");
            string sDestinataryDeposit = Console.ReadLine();
            bankAccounts client = transAccount.searchInfoClient(sDestinataryDeposit);

            if (client != null)
            {
                int amountDestinatary = Convert.ToInt32(client.ClientCurrentMoney);
                amountDestinatary += i;
                client.ClientCurrentMoney = amountDestinatary.ToString();
                string jsonofClients = JsonConvert.SerializeObject(transAccount.getList(), Formatting.Indented);
                File.WriteAllText(transAccount.asignarRuta("database.json"), jsonofClients);
                Console.WriteLine("El ingreso ingreso se ha hecho correctamente.");
            }
            else
            {
                Console.WriteLine("Lo siento, el destinatario no esta en nuestra base de datos o lo has introducido mal");
                Console.WriteLine("------------------------------------------------------------------------------------");
                Console.WriteLine("1 para volver a intentar hacer el ingreso");
                Console.WriteLine("2 para seguir gestionando tu cuenta");
                Console.WriteLine("3 para terminar la operaciones y salir");
                int option = Convert.ToInt32(Console.ReadLine());
                
                MenuBank menuTrans = new MenuBank();    
                switch(option){
                    case 1:
                    {
                        menuTrans.opcionesGestionar();
                        break;
                    }
                    case 2:
                    {
                        Console.WriteLine("Vuelve a poner el importe del ingreso");
                        int x = Convert.ToInt32(Console.ReadLine());
                        checkDestinataryDeposit(x);
                        break;        
                    }
                    case 3:
                    {
                        menuTrans.setFinalise(true);
                        Console.WriteLine("Has termiando las operaciones y has salido");
                        break;        
                    }
                    default:
                    {
                        while(option< 1 || option > 3){
                            Console.WriteLine("Lo has introducido mal");
                            Console.WriteLine("----------------------");
                            Console.WriteLine("1 para volver a hacer el ingreso");
                            Console.WriteLine("2 para seguir gestionando tu cuenta");
                            Console.WriteLine("3 para terminar la operaciones y salir");
                            option = Convert.ToInt32(Console.ReadLine());
                        }     
                        
                        switch(option){
                            case 1:
                            {
                                menuTrans.opcionesGestionar();
                                break;
                            }
                            case 2:
                            {
                                Console.WriteLine("Vuelve a poner el importe del ingreso");
                                int x = Convert.ToInt32(Console.ReadLine());
                                checkDestinataryDeposit(x);
                                break;        
                            }
                            case 3:
                            {
                                menuTrans.setFinalise(true);
                                Console.WriteLine("Has termiando las operaciones y has salido");
                                break;        
                            }            
                        }
                        break;
                    }
                }  
            }
        }


        public void withdrawMoney()  //case 3 menuOption3
        {
            
            MenuBank menuTrans = new MenuBank();
            Console.WriteLine("Has entrado en sacar dinero");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                menuTrans.opcionesGestionar();
            }
            else
            {//Seguir para sacar dinero
                Console.WriteLine("¿Cuánto dinero quieres sacar?");
                int iTransferWithdraw = Convert.ToInt32(Console.ReadLine());
                if (iTransferWithdraw < 1)
                {//Para que meta una cantidad positiva
                    Console.WriteLine("Has introducido un número negativo, no puedes poner menos de 1");
                    while (iTransferWithdraw < 1)
                    {
                        Console.WriteLine("Prueba otra vez");
                        iTransferWithdraw = Convert.ToInt32(Console.ReadLine());
                    }
                }
                checkDestinataryWithdraw(iTransferWithdraw);
                menuTrans.gestionarSalir();
            }
        }

        public void checkDestinataryWithdraw(int i)
        {
            
            bankAccounts transAccount = new bankAccounts();
            MenuBank menuTrans = new MenuBank();
            bankAccounts client = transAccount.searchInfoClient(transAccount.getClientName());
            int currentAmount = Convert.ToInt32(client.ClientCurrentMoney);

            if ((currentAmount - i) > 0)
            {
                currentAmount -= i;
                client.ClientCurrentMoney = currentAmount.ToString();
                client.listaTransacciones.Add("Se ha sacado " + i.ToString() + " euros");
                
                string jsonofClients = JsonConvert.SerializeObject(transAccount.getList(), Formatting.Indented);
                File.WriteAllText(transAccount.asignarRuta("database.json"), jsonofClients);
                
                Console.WriteLine("Proceso existoso");
            }
            else//Si la cantidad que intenta sacar no puede le da opciones
            {
                Console.WriteLine("Lo siento, no puedes sacar tanto dinero");
                Console.WriteLine("------------------------------------------------------------------------------------");
                Console.WriteLine("1 para volver a intentar sacar dinero");
                Console.WriteLine("2 para seguir gestionando tu cuenta");
                Console.WriteLine("3 para terminar la operaciones y salir");
                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        {
                            Console.WriteLine("Vuelve a poner el la cantidad que quieres sacar");
                            int j = Convert.ToInt32(Console.ReadLine());
                            checkDestinataryWithdraw(j);
                            break;
                        }
                    case 2:
                        {
                            menuTrans.opcionesGestionar();  
                            break;
                        }
                    case 3:
                        {
                            menuTrans.setFinalise(true);
                            Console.WriteLine("Has termiando las operaciones y has salido");
                            break;
                        }
                    default:
                        {
                            while (option != 1 || option != 2 || option != 3)
                            {//Me aseguro de que lo mete bien
                                Console.WriteLine("Lo has introducido mal");
                                Console.WriteLine("----------------------");
                                Console.WriteLine("1 para volver a sacar dinero");
                                Console.WriteLine("2 para seguir gestionando tu cuenta");
                                Console.WriteLine("3 para terminar la operaciones y salir");
                                option = Convert.ToInt32(Console.ReadLine());
                            }
                            switch (option)
                            {
                                case 1:
                                    {
                                        Console.WriteLine("Vuelve a poner el la cantidad que quieres sacar");
                                        int j = Convert.ToInt32(Console.ReadLine());
                                        checkDestinataryWithdraw(j);
                                        break;
                                    }
                                case 2:
                                    {
                                        menuTrans.opcionesGestionar();
                                        break;
                                    }
                                case 3:
                                    {
                                        menuTrans.setFinalise(true);
                                        Console.WriteLine("Has termiando las operaciones y has salido");
                                        break;
                                    }
                            }
                            break;
                        }
                }
            }
        }

        public void makeTransfer()//case 4 menuOption3
        {

            bankAccounts transAccount = new bankAccounts();
            MenuBank menuTrans = new MenuBank();
            Console.WriteLine("Has entrado en hacer una tranferencia");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                menuTrans.opcionesGestionar();
            }
            else
            {//seguir para hacer la transferencia
                Console.WriteLine("¿De cuanto quieres hacer la transferencia?");
                int iTransAmount = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("¿A quién quieres hacer la transferencia?");
                string sDestinataryTransfer = Console.ReadLine();

                bankAccounts Destine = transAccount.searchInfoClient(sDestinataryTransfer);
                bankAccounts origin = transAccount.searchInfoClient(transAccount.getClientName());

                if (Destine != null)
                {//Verifica si el destinatario existe

                    int iGetMoneyOrigin = Convert.ToInt32(origin.ClientCurrentMoney);
                    int iGetMoneyDestinatary = Convert.ToInt32(Destine.ClientCurrentMoney);

                    if (iGetMoneyOrigin - iTransAmount < 0)//Si lo que tiene es menos de lo que quiere transferir doy diferentes opciones
                    {
                        Console.WriteLine("Lo siento, no puedes hacer la transferencia porque no tienes tanto dinero en tu cuenta");
                        Console.WriteLine("------------------------------------------------------------------------------------");
                        Console.WriteLine("1 para intentar ha hacer la transferencia");
                        Console.WriteLine("2 para seguir gestionando tu cuenta");
                        Console.WriteLine("3 para terminar la operaciones y salir");
                        int option = Convert.ToInt32(Console.ReadLine());

                        switch (option)
                        {
                            case 1:
                                {
                                    makeTransfer();
                                    break;
                                }
                            case 2:
                                {
                                    menuTrans.opcionesGestionar(); //Entra otra vez en el menú general de gestionar cuenta 
                                    break;
                                }
                            case 3:
                                {
                                    menuTrans.setFinalise(true);
                                    Console.WriteLine("Has termiando las operaciones y has salido");
                                    break;
                                }
                            default:
                                {
                                    while (option < 1 || option > 3)
                                    {//Me aseguro de que lo mete bien
                                        Console.WriteLine("Lo has introducido mal");
                                        Console.WriteLine("----------------------");
                                        Console.WriteLine("1 para intentar hacer la transferencia");
                                        Console.WriteLine("2 para seguir gestionando tu cuenta");
                                        Console.WriteLine("3 para terminar la operaciones y salir");
                                        option = Convert.ToInt32(Console.ReadLine());
                                    }

                                    switch (option)
                                    {
                                        case 1:
                                            {
                                                makeTransfer();
                                                break;
                                            }
                                        case 2:
                                            {
                                                menuTrans.opcionesGestionar(); 
                                                break;
                                            }
                                        case 3:
                                            {
                                                menuTrans.setFinalise(true);
                                                Console.WriteLine("Has termiando las operaciones y has salido");
                                                break;
                                            }
                                    }
                                    break;
                                }
                        }
                    }
                    else
                    {
                        iGetMoneyDestinatary += iTransAmount;
                        iGetMoneyOrigin -= iTransAmount;
                        Destine.ClientCurrentMoney = iGetMoneyDestinatary.ToString();
                        origin.ClientCurrentMoney = iGetMoneyOrigin.ToString();
                        
                        Destine.listaTransacciones.Add("Se ha transferido " + iTransAmount + " euros de " + origin.clientName + " a " + Destine.clientName);
                        origin.listaTransacciones.Add("Se ha transferido " + iTransAmount + " euros de " + origin.clientName + " a " + Destine.clientName);
                        
                        string jsonofClients = JsonConvert.SerializeObject(transAccount.getList(), Formatting.Indented);
                        File.WriteAllText(transAccount.asignarRuta("database.json"), jsonofClients);
                        
                        Console.WriteLine("La transferencia se ha realizado correctamente.");
                        menuTrans.gestionarSalir();
                    }
                }
                else
                {
                    Console.WriteLine("La pesona a la que quieres enviar el dinero no esta en nuestra base de datos");
                    Console.WriteLine("----------------------------------------------------------------------------");
                    Console.WriteLine("1 Para volver a intentar hacer la transferencia");
                    Console.WriteLine("2 Para volver al menú y gestionar la cuenta");
                    Console.WriteLine("3 Para terminar las operaciones");
                    int option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            {
                                makeTransfer();
                                break;
                            }
                        case 2:
                            {
                                menuTrans.opcionesGestionar(); 
                                break;
                            }
                        case 3:
                            {
                                menuTrans.setFinalise(true);
                                Console.WriteLine("Has termiando las operaciones y has salido");
                                break;
                            }
                        default:
                            {
                                while (option < 1 || option > 3)
                                {//Me aseguro de que lo mete bien
                                    Console.WriteLine("Lo has introducido mal");
                                    Console.WriteLine("----------------------");
                                    Console.WriteLine("1 para intentar hacer la transferencia");
                                    Console.WriteLine("2 para seguir gestionando tu cuenta");
                                    Console.WriteLine("3 para terminar la operaciones y salir");
                                    option = Convert.ToInt32(Console.ReadLine());
                                }

                                switch (option)
                                {
                                    case 1:
                                        {
                                            makeTransfer();
                                            break;
                                        }
                                    case 2:
                                        {
                                            menuTrans.opcionesGestionar(); //Entra otra vez en el menú general de gestionar cuenta 
                                            break;
                                        }
                                    case 3:
                                        {
                                            menuTrans.setFinalise(true);
                                            Console.WriteLine("Has termiando las operaciones y has salido");
                                            break;
                                        }
                                }
                                break;
                            }
                    }
                }
            }
        }
    }
}
