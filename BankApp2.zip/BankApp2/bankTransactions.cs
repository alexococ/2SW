namespace bankApp{
    public class bankTransactions{

        private float AmountTransaction{ get; set;}
        private string []? listMovements { get; set;}

        //Constructor
       
        //Método get
        public float getAmountTransaction(){//Da la cantidad de la transación
            return AmountTransaction;
        }

        public string [] getInfoTransactions(){// Da la lista de los últimos moviemientos
            return listMovements;
        }


        //Método set 

        public void lastTransactions(string movement){//Acumula los últimos movimientos
            int sizeArray = 100;
            string[]? listMovement = new string[sizeArray];
            int blank = 0;    
            for(int x = 0; x < listMovement.Length; x++){
                while(listMovement[x] != null){
                    x++;
                    blank = x;
                }
                listMovement[blank] = movement;
            }
            this.listMovements = listMovement;
        }
    }
}