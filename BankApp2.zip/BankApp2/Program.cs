﻿// See https://aka.ms/new-console-template for more information

using bankApp;

    bankAccounts bAccount = new bankAccounts();
    bankTransactions btrans = new bankTransactions();
    MenuBank menuB = new MenuBank();
    Console.WriteLine("holaa");
    bool finalise = false;
    while(finalise != true){
        int option = menuB.MenuConsola();
        if(option == 1){
            
        }
    }
