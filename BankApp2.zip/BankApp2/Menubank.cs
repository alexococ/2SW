namespace bankApp{
    public class MenuBank{
    
        //Menú de la consola
        public int MenuConsola(){//Menú incial
            Console.WriteLine("Hola, Bienvenido a SvBank");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Tiene diferentes opciones: (pulse el número correspodiente)");
            Console.WriteLine("     1 Crear una cuenta");
            Console.WriteLine("     2 Entrar en una cuenta");
            string? sNumber = Console.ReadLine();
            int option = int.Parse(sNumber);
            int number;
            if(!int.TryParse(sNumber , out number) || option < 1 || option > 2){
                Console.WriteLine("Lo siento, lo has introducido mal, tienes que introducir 1 o 2");
                MenuConsola();
            }
            return  number;
        }    
    
        public int MenuOption1(){//Menú crear una cuenta
            Console.WriteLine("Introduce el nombre");
            string clientName = Console.ReadLine();
            Console.
        }
    
    
    
    }
}