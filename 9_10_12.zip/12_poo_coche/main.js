class Coche {
    constructor(marca, modelo, consumoPor100) {
        this.marca = marca; 
        this.modelo = modelo;
        this.consumoPor100 = consumoPor100;
        this.totalGasolina = 0;
    }

    repostar(litros) {
        if (litros > 0) {
            this.totalGasolina += litros;
            return `Se han añadido ${litros} litros de gasolina. Total: ${this.totalGasolina} litros.`;
        } else {
            return 'La cantidad de litros debe ser mayor que cero.';
        }
    }

    mover(distancia) {
        const litrosNecesarios = (distancia / 100) * this.consumoPor100;
        if (litrosNecesarios <= this.totalGasolina) {
            this.totalGasolina -= litrosNecesarios;
            return `Se han consumido ${litrosNecesarios} litros de gasolina. Total restante: ${this.totalGasolina} litros.`;
        } else {
            return 'No hay suficiente gasolina para recorrer esa distancia.';
        }
    }

    restante() {
        const kmRestantes = (this.totalGasolina / this.consumoPor100) * 100;
        return `Puedes recorrer aproximadamente ${kmRestantes} kilómetros.`;
    }
}

// Ejemplo de uso:
let miCoche = new Coche("Toyota", "Corolla", 5.5);
console.log(miCoche.repostar(30)); // Output: "Se han añadido 30 litros de gasolina. Total: 30 litros."
console.log(miCoche.mover(150)); // Output: "Se han consumido 8.25 litros de gasolina. Total restante: 21.75 litros."
console.log(miCoche.restante()); // Output: "Puedes recorrer aproximadamente 395.45454545454544 kilómetros."
