window.onload = function() {
    console.log('documento cargado');

    document.getElementById('loadData').addEventListener('click', loadData);
}

function loadData() {
    fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => response.json())
        .then(data => {
            const employeeList = document.getElementById('employeeList');
            employeeList.innerHTML = '';

            data.forEach(user => {
                const listItem = document.createElement('li');
                listItem.textContent = `ID: ${user.id}, Name: ${user.name}, Email: ${user.email}`;
                employeeList.appendChild(listItem);
            });
        })
        .catch(error => console.error('There was a problem with the fetch operation:', error));
}
