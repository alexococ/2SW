document.getElementById('cargarDatos').addEventListener('click', function() {
    fetch('https://reqres.in/api/users')
        .then(response => response.json())
        .then(data => {
            const tablaUsuarios = document.getElementById('tablaUsuarios');
            const tbody = tablaUsuarios.querySelector('tbody');

            // Limpiar filas anteriores si las hay
            tbody.innerHTML = '';

            data.data.forEach(usuario => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${usuario.id}</td>
                    <td>${usuario.first_name} ${usuario.last_name}</td>
                    <td>${usuario.email}</td>
                `;
                tbody.appendChild(fila);
            });
        })
        .catch(error => console.error('Error:', error));
});