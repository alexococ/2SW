
document.addEventListener('keyup', (e) => {
    if(e.code === "Space" || e.keyCode === 32){
        const cuadrado = document.getElementById('cuadrado')
        cuadrado.classList.toggle('animate')
    }
  });
  