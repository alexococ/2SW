using System.Formats.Asn1;
using System.Threading.Tasks.Dataflow;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;

namespace bankApp{
    public class MenuBank{
        public string clientName {get; set;}
        public string ClientDirection {get; set;}
        public int ClientPhoneNumber {get; set;}
        public int ClientCurrentMoney {get; set;}
        //get de las variables
        public string getClientName(){
            return this.clientName;
        }

        public string getClientDirection(){
            return this.ClientDirection;
        }
        public int getClientPhone(){
            return this.ClientPhoneNumber;
        }

        public int getClientMoney(){
            return this.ClientCurrentMoney;
        }

        //Menú de la consola
        public int MenuConsola(){//Menú incial
            Console.WriteLine("Hola, Bienvenido a SvBank");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Tiene diferentes opciones: (pulse el número correspodiente)");
            Console.WriteLine("1 Crear una cuenta");
            Console.WriteLine("2 Entrar en una cuenta");
            string sNumber = Console.ReadLine();
            int option = int.Parse(sNumber);
            int number;
            if(int.TryParse(sNumber, out number) || option < 1 || option > 2){//si lo mete mal repite
                Console.WriteLine("Lo siento, lo has introducido mal, tienes que introducir 1 o 2");
                MenuConsola();
            }
            return  number;
        }    
    
        public void MenuOption1(){//Menú crear una cuenta(recoge los datos)
            Console.WriteLine("Vamos a proceder a rellenar los datos para crear la cuenta");
            Console.WriteLine("-----------------------------------------------------------");
            
            Console.WriteLine("Introduce el nombre y apellidos");
            this.clientName = Console.ReadLine();
            
            Console.WriteLine("Introduce tu dirección");
            this.ClientDirection = Console.ReadLine();
            
            Console.WriteLine("Introduce tu número de teléfono");
            string ClientPhone = Console.ReadLine();
            this.ClientPhoneNumber = int.Parse(ClientPhone);

            Console.WriteLine("Para terminar, introduce la cantidad con la que quieres iniciar tu cuenta");
            string Clientmoney = Console.ReadLine();
             ClientCurrentMoney = int.Parse(ClientPhone);   
        }

        public void MenuOption2(){//Menú que pide el nombre después de entrar en la opción de gestionar cuenta
            Console.WriteLine("Has entrado en la opción de gestionar cuenta, ¿Qué deseas hacer?");
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("Pon tu nombre y apellidos para entrar en tu cuenta");
            clientName = Console.ReadLine();
            //Hacer la comprobación de que el nombre está en el Json!!!!!
        }
        public int MenuOption3(){//Menú dentro de gestionar cuenta
            Console.WriteLine("Has entraado,¿Qué quieres hacer?");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("1 Para cambiar los datos de la cuenta");
            Console.WriteLine("2 Para hacer una transferencia");
            Console.WriteLine("3 Para sacar dinero");
            Console.WriteLine("4 Para ingresar dinero");
            Console.WriteLine("5 Para ver los últimos moviemientos de la cuenta");
            string sOption = Console.ReadLine();
            int iOption = int.Parse(sOption);
            return iOption;
        }


        public void changeDetails(){//Cambiar datos de la cuenta
            Console.WriteLine("Has elegido cambiar los datos de la cuenta");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("¿Qué quieres cambiar?");
            Console.WriteLine("--------------------");
            Console.WriteLine("1 El nombre del dueño de la cuenta");
            Console.WriteLine("2 La dirección");
            Console.WriteLine("3 El número de teléfono");
            string sOptionChangeDetails = Console.ReadLine();
            int iOptionChangeDetails = int.Parse(sOptionChangeDetails);
            
            switch(iOptionChangeDetails){
                
            }

        }

        



    }
}