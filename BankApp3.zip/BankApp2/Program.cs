﻿// See https://aka.ms/new-console-template for more information
using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using bankApp;

internal class Program
{
    private static void Main(string[] args){
        bankAccounts bAccount = new bankAccounts();
        bankTransactions btrans = new bankTransactions();
        MenuBank menuB = new MenuBank();
        Console.WriteLine("holaa");
        
        bool finalise = false;
        
        while (finalise != true){
            int option = menuB.MenuConsola();
            if (option == 1)
            {
                menuB.MenuOption1();
                string baseDatosJson = File.ReadAllText("bd.json");//lee el json

                var opciones = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                dynamic datos = JsonSerializer.Deserialize<dynamic>(baseDatosJson, opciones);

                // Paso 3: Agregar nueva información
                datos["clientes"].Add(new MenuBank { 
                                                    clientName = menuB.getClientName(), 
                                                    ClientDirection = menuB.getClientDirection(), 
                                                    ClientPhoneNumber = menuB.getClientPhone(), 
                                                    ClientCurrentMoney = menuB.getClientMoney() 
                                                    });
                
                // Paso 4: Serializar la estructura de datos actualizada de regreso a JSON
                string jsonActualizado = JsonSerializer.Serialize(datos, typeof(object), opciones);

                // Paso 5: Escribir el JSON actualizado en el archivo
                File.WriteAllText("bd.json", jsonActualizado);

                Console.WriteLine("Información agregada correctamente");

            }
            if(option == 2){
                menuB.MenuOption2();
                int optionUser = menuB.MenuOption3();
                
            
            }




        }
    }
}