using System.Globalization;
using System.Runtime;

namespace Models;
public class BankAccount{
    public string Number{get;set;}
    public string Owner{get;set;} = "";
    public decimal Balance{get;set;}

    public void MakeDeposit(decimal amount, DateTime date, string note){

    }
    public void MakeWithdrawal(decimal amount, DateTime date, string note){

    }
    
    public BankAccount(string? owner, decimal balance){
        Owner = owner;
        Balance = balance;
    }

    public override string ToString(){
        return Owner ?? "No Owner";
    }


    public BankAccount(String number){
        Number = "0";
    }

}

