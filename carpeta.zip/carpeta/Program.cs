﻿// See https://aka.ms/new-console-template for more information
using System.Threading.Tasks.Dataflow;
using Models;

Console.WriteLine("Hello, World!");

BankAccount account = new BankAccount("Daniel", 100);
var stringfAccount = account.ToString();
Console.WriteLine(stringfAccount);

BankAccount account2 = new BankAccount("Manolo");
Console.WriteLine("bye,world!");
