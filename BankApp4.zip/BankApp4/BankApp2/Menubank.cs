using System.Formats.Asn1;
using System.Threading.Tasks.Dataflow;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace bankApp
{
    public class MenuBank
    {
        Database db = new Database();
        bankTransactions bTrans = new bankTransactions();


        public string clientName { get; set; }
        public string ClientDirection { get; set; }
        public string ClientPhoneNumber { get; set; }
        public string ClientCurrentMoney { get; set; }
        public bool Finalise { get; set; }
        //get de las variables
        public string getClientName()
        {
            return this.clientName;
        }

        public string getClientDirection()
        {
            return this.ClientDirection;
        }
        public string getClientPhone()
        {
            return this.ClientPhoneNumber;
        }

        public string getClientMoney()
        {
            return this.ClientCurrentMoney;
        }

        public bool getFinalise()
        {
            return Finalise;
        }

        public void setFinalise(bool s)
        {
            this.Finalise = s;
        }

        //Menú de la consola
        public int MenuConsola()
        {//Menú incial
            Console.WriteLine("Hola, Bienvenido a SvBank");
            Console.WriteLine("-------------------------");
            Console.WriteLine("Tiene diferentes opciones: (pulse el número correspodiente)");
            Console.WriteLine("1 Crear una cuenta");
            Console.WriteLine("2 Entrar en una cuenta");
            string sNumber = Console.ReadLine();
            //int option = int.Parse(sNumber);
            if (!int.TryParse(sNumber, out int number) || number < 1 || number > 2)
            {//si lo mete mal repite
                Console.WriteLine("Lo siento, lo has introducido mal, tienes que introducir 1 o 2");
                MenuConsola();
            }
            return number;
        }

        public void MenuOption1()
        {//Menú crear una cuenta(recoge los datos)
            Console.WriteLine("Vamos a proceder a rellenar los datos para crear la cuenta");
            Console.WriteLine("-----------------------------------------------------------");

            Console.WriteLine("Introduce el nombre y apellidos");
            this.clientName = Console.ReadLine();

            Console.WriteLine("Introduce tu dirección");
            this.ClientDirection = Console.ReadLine();

            Console.WriteLine("Introduce tu número de teléfono");
            this.ClientPhoneNumber = Console.ReadLine();


            Console.WriteLine("Para terminar, introduce la cantidad con la que quieres iniciar tu cuenta");
            this.ClientCurrentMoney = Console.ReadLine();

        }

        public void MenuOption2()
        {//Menú que pide el nombre después de entrar en la opción de gestionar cuenta
            Console.WriteLine("Has entrado en la opción de gestionar cuenta, ¿Qué deseas hacer?");
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("Pon tu nombre y apellidos para entrar en tu cuenta");
            clientName = Console.ReadLine();
            //Hacer la comprobación de que existe la tabla
        }
        public void MenuOption3()
        {//Menú dentro de gestionar cuenta
            Console.WriteLine("Has entrado en gestionar cuenta, ¿Qué quieres hacer?");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("1 Para cambiar los datos de la cuenta");
            Console.WriteLine("2 Para ingresar dinero");
            Console.WriteLine("3 Para sacar dinero");
            Console.WriteLine("4 Para hacer una transferencias");
            Console.WriteLine("5 Para ver los últimos moviemientos de la cuenta");
            int iOption = Convert.ToInt32(Console.ReadLine());
            
            switch (iOption)
            {
                case 1: { changeDetails(); break; }
                case 2: { makeDeposit(); break; }
                case 3: { withdrawMoney(); break; }
                case 4: { makeTransfer(); break; }
                //terminar case 5
            }
        }


        public void changeDetails()
        {
            Console.WriteLine("Has elegido cambiar los datos de la cuenta");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("¿Qué quieres cambiar?");
            Console.WriteLine("--------------------");
            Console.WriteLine("1 El nombre del dueño de la cuenta");
            Console.WriteLine("2 La dirección");
            Console.WriteLine("3 El número de teléfono");
            int iOptionChangeDetails = Convert.ToInt32(Console.ReadLine());

            switch (iOptionChangeDetails)
            {//Cambiar algunos datos por campo
                case 1:
                    {//Cambiar el nombre 
                        Console.WriteLine("¿Cuál es el nuevo nombre?");
                        string sNewName = Console.ReadLine();
                        db.ActualizarCampo(clientName, "Name", sNewName);
                        Console.WriteLine("El nombre se ha cambiado correctamente");
                        bTrans.addListMovements("Se ha cambiado el nombre de la cuenta a " + sNewName);
                        break;
                    }
                case 2:
                    {//Cambiar la dirección 
                        Console.WriteLine("¿Cuál es la nueva dirección?");
                        string sNewName = Console.ReadLine();
                        db.ActualizarCampo(clientName, "Address", sNewName);
                        Console.WriteLine("La dirección se ha cambiado correctamente");
                        bTrans.addListMovements("Se ha cambiado la dirección de la cuenta a " + sNewName);
                        break;
                    }
                case 3:
                    {//Cambiar el número de teléfono 
                        Console.WriteLine("¿Cuál es el nuevo número de teléfono?");
                        string sNewName = Console.ReadLine();
                        db.ActualizarCampo(clientName, "PhoneNumber", sNewName);
                        Console.WriteLine("El nombre se ha cambiado correctamente");
                        bTrans.addListMovements("Se ha cambiado número de teléfono de la cuenta a " + sNewName);
                        break;
                    }
            }
            Console.WriteLine("Lsos cambios se han hecho exitosamente.");
            gestionarSalir();
        }
    
        public void gestionarSalir()
        {//Menú para seguir gestionando o salir
            Console.WriteLine("¿Que quieres hacer?");
            Console.WriteLine("-------------------");
            Console.WriteLine("1 Para seguir gestionando o 2 para salir");
            string sOption = Console.ReadLine();

            if (sOption == "1")
            {
                MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
            }
            if (sOption == "2")
            {
                setFinalise(true);
                Console.WriteLine("Has termiando las operaciones");
            }
            if (sOption != "1" || sOption != "2")
            {
                Console.WriteLine("Lo has introducido mal, tienes que introducir 1 para seguir gestionando o 2 para salir");
                Console.WriteLine();
                gestionarSalir();
            }
        }


        public void makeDeposit() //case 2 menuOption3
        {
            Console.WriteLine("Has entrado en hacer un ingreso");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                MenuOption3();
            }
            else
            {//Seguir con la transferencia
                Console.WriteLine("¿De cuanto quieres hacer el ingreso?");
                int iTransferDeposit = Convert.ToInt32(Console.ReadLine());
                if (iTransferDeposit < 1)
                {//Para que meta una cantidad positiva
                    Console.WriteLine("Has introducido un número negativo, no puedes poner menos de 1");
                    while (iTransferDeposit < 1)
                    {
                        Console.WriteLine("Prueba otra vez");
                        iTransferDeposit = Convert.ToInt32(Console.ReadLine());
                    }
                }
                checkDestinataryDeposit(iTransferDeposit);//Hace el ingreso
                gestionarSalir();
            }
        }

        public void checkDestinataryDeposit(int i)
        {//comprueba que el destinatario existe para hacer el ingreso
            Console.WriteLine("A quién quieres hacer el ingreso?");
            string sDestinataryDeposit = Console.ReadLine();

            if (db.VerificarExistenciaTablaPorNombre(sDestinataryDeposit))
            {//Comprueba que existe la tabla 
                int iGetMoney = db.ObtenerCampo<int>(sDestinataryDeposit, "CurrentMoney");
                i += iGetMoney;
                db.ActualizarCampo(sDestinataryDeposit, "CurrentMoney", i);
                string s = i.ToString();
                bTrans.addListMovements("Se ha hecho un ingreso a " + sDestinataryDeposit + " de " + s  + " euros.");
                Console.WriteLine("El ingreso se ha hecho existosamente");
            }
            else
            {//Si no se ha detectado que no existe
                Console.WriteLine("Lo siento, el destinatario no esta en nuestra base de datos o lo has introducido mal");
                Console.WriteLine("------------------------------------------------------------------------------------");
                Console.WriteLine("1 para volver a intentar hacer la transferencia");
                Console.WriteLine("2 para seguir gestionando tu cuenta");
                Console.WriteLine("3 para terminar la operaciones y salir");
                string sOption = Console.ReadLine();
                if (sOption == "2")
                {
                    MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                }
                if (sOption == "1")
                {//vuelve a intentar el ingreso
                    Console.WriteLine("Vuelve a poner el importe del ingreso");
                    int x = Convert.ToInt32(Console.ReadLine());
                    checkDestinataryDeposit(x);
                }
                if (sOption == "3")
                {
                    setFinalise(true);
                    Console.WriteLine("Has termiando las operaciones y has salido");
                }

                if (sOption != "1" || sOption != "2" || sOption != "3")
                {//si ha metido mal la opción 
                    Console.WriteLine("Lo has introducido mal");
                    Console.WriteLine("----------------------");
                    Console.WriteLine("1 para volver a hacer el ingreso");
                    Console.WriteLine("2 para seguir gestionando tu cuenta");
                    Console.WriteLine("3 para terminar la operaciones y salir");
                    string sSecondChance = Console.ReadLine();

                    while (sSecondChance != "1" || sSecondChance != "2" || sSecondChance != "3")
                    {//Me aseguro de que lo mete bien
                        Console.WriteLine("Lo has introducido mal");
                        Console.WriteLine("----------------------");
                        Console.WriteLine("1 para volver a el ingreso");
                        Console.WriteLine("2 para seguir gestionando tu cuenta");
                        Console.WriteLine("3 para terminar la operaciones y salir");
                        sSecondChance = Console.ReadLine();
                    }
                    if (sSecondChance == "2")
                    {
                        MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                    }
                    if (sSecondChance == "1")
                    {//vuelve a intentar la transferencia
                        Console.WriteLine("Vuelve a poner el importe del ingreso");
                        string x = Console.ReadLine();
                        int j = int.Parse(x);
                        checkDestinataryDeposit(j);
                    }
                    if (sSecondChance == "3")
                    {
                        setFinalise(true);
                        Console.WriteLine("Has termiando las operaciones y has salido");
                    }
                }

            }
        }

        public void withdrawMoney()  //case 3 menuOption3
        {
            Console.WriteLine("Has entrado en sacar dinero");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                MenuOption3();
            }
            else
            {//Seguir para sacar dinero
                Console.WriteLine("¿Cuánto dinero quieres sacar?");
                string sTransferWithdraw = Console.ReadLine();
                int iTransferWithdraw = int.Parse(sTransferWithdraw);
                if (iTransferWithdraw < 1)
                {//Para que meta una cantidad positiva
                    Console.WriteLine("Has introducido un número negativo, no puedes poner menos de 1");
                    while (iTransferWithdraw < 1)
                    {
                        Console.WriteLine("Prueba otra vez");
                        sTransferWithdraw = Console.ReadLine();
                        iTransferWithdraw = int.Parse(sTransferWithdraw);
                    }
                }
                checkDestinataryWithdraw(iTransferWithdraw);//Hace el proceso para sacar dinero
                gestionarSalir();
            }
        }

        public void checkDestinataryWithdraw(int i)
        {
            int iGetMoney = db.ObtenerCampo<int>(clientName, "CurrentMoney");//Obtiene la cantidad para restarla

            if ((iGetMoney - i) > 0)
            {
                iGetMoney -= i;
                string s = i.ToString();
                db.ActualizarCampo(clientName, "CurrentMoney", iGetMoney);//Ingresa el dinero de nuevo ya restado 
                bTrans.addListMovements("Se ha sacado un importe de " + s + " euros.");
                Console.WriteLine("Proceso existoso");
            }
            else//Si la cantidad que intenta sacar no puede le da opciones
            {
                Console.WriteLine("Lo siento, no puedes sacar tanto dinero");
                Console.WriteLine("------------------------------------------------------------------------------------");
                Console.WriteLine("1 para volver a intentar sacar dinero");
                Console.WriteLine("2 para seguir gestionando tu cuenta");
                Console.WriteLine("3 para terminar la operaciones y salir");
                string sOption = Console.ReadLine();
                if (sOption == "2")
                {
                    MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                }
                if (sOption == "1")
                {//vuelve a intentar el ingreso
                    Console.WriteLine("Vuelve a poner el la cantidad que quieres sacar");
                    string x = Console.ReadLine();
                    int j = int.Parse(x);
                    checkDestinataryWithdraw(j);
                }
                if (sOption == "3")
                {
                    setFinalise(true);
                    Console.WriteLine("Has termiando las operaciones y has salido");
                }

                if (sOption != "1" || sOption != "2" || sOption != "3")
                {//si ha metido mal la opción 
                    Console.WriteLine("Lo has introducido mal");
                    Console.WriteLine("----------------------");
                    Console.WriteLine("1 para intentar sacar dinero de nuevo");
                    Console.WriteLine("2 para seguir gestionando tu cuenta");
                    Console.WriteLine("3 para terminar la operaciones y salir");
                    string sSecondChance = Console.ReadLine();

                    while (sSecondChance != "1" || sSecondChance != "2" || sSecondChance != "3")
                    {//Me aseguro de que lo mete bien
                        Console.WriteLine("Lo has introducido mal");
                        Console.WriteLine("----------------------");
                        Console.WriteLine("1 para volver a sacar dinero");
                        Console.WriteLine("2 para seguir gestionando tu cuenta");
                        Console.WriteLine("3 para terminar la operaciones y salir");
                        sSecondChance = Console.ReadLine();
                    }
                    if (sSecondChance == "2")
                    {
                        MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                    }
                    if (sSecondChance == "1")
                    {//vuelve a intentar la transferencia
                        Console.WriteLine("Vuelve a poner la cantidad que quieres sacar");
                        string x = Console.ReadLine();
                        int j = int.Parse(x);
                        checkDestinataryWithdraw(j);
                    }
                    if (sSecondChance == "3")
                    {
                        setFinalise(true);
                        Console.WriteLine("Has termiando las operaciones y has salido");
                    }
                }
            }
        }

        public void makeTransfer()//case 4 menuOption3
        {
            Console.WriteLine("Has entrado en hacer una tranferencia");
            Console.WriteLine("si te has equivocado introduce 1 y seras devuelto al menú de gestionar cuenta");
            string sTrans = Console.ReadLine();

            if (sTrans == "1")
            {//Volver al menú general de gestionar cuenta
                MenuOption3();
            }
            else
            {//seguir para hacer la transferencia
                Console.WriteLine("¿De cuanto quieres hacer la transferencia?");
                string sTransAmount = Console.ReadLine();
                int iTransAmount = int.Parse(sTransAmount);
                Console.WriteLine("¿A quién quieres hacer la transferencia?");
                string sDestinataryTransfer = Console.ReadLine();

                if (db.VerificarExistenciaTablaPorNombre(sDestinataryTransfer))//Verifica si existe el destinatario
                {//Verifica si el destinatario existe
                    int iGetMoneyeDestinatary = db.ObtenerCampo<int>(sDestinataryTransfer, "CurrentMoney"); //obtengo la cantidad del destinatario
                    int iGetMoneyOrigin = db.ObtenerCampo<int>(clientName, "CurrentMoney");//Obtengo la cantidad del origen              
                    //proceso para hacer la transferencia de una cuenta a otra
                    if (iGetMoneyOrigin - iTransAmount < 0)//Si lo que tiene es menos de lo que quiere transferir doy diferentes opciones
                    {
                        Console.WriteLine("Lo siento, no puedes hacer la transferencia porque no tienes tanto dinero en tu cuenta");
                        Console.WriteLine("------------------------------------------------------------------------------------");
                        Console.WriteLine("1 para intentar ha hacer la transferencia");
                        Console.WriteLine("2 para seguir gestionando tu cuenta");
                        Console.WriteLine("3 para terminar la operaciones y salir");
                        string sOption = Console.ReadLine();
                        if (sOption == "2")
                        {
                            MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                        }
                        if (sOption == "1")
                        {//vuelve a intentar hacer la transferencia
                            makeTransfer();
                        }
                        if (sOption == "3")
                        {
                            setFinalise(true);
                            Console.WriteLine("Has termiando las operaciones y has salido");
                        }

                        if (sOption != "1" || sOption != "2" || sOption != "3")//me aseguro de que introduzca  1 , 2 o 3
                        {//si ha metido mal la opción 
                            Console.WriteLine("Lo has introducido mal");
                            Console.WriteLine("----------------------");
                            Console.WriteLine("1 para intentar hacer la transferencia de nuevo");
                            Console.WriteLine("2 para seguir gestionando tu cuenta");
                            Console.WriteLine("3 para terminar la operaciones y salir");
                            string sSecondChance = Console.ReadLine();

                            while (sSecondChance != "1" || sSecondChance != "2" || sSecondChance != "3")
                            {//Me aseguro de que lo mete bien
                                Console.WriteLine("Lo has introducido mal");
                                Console.WriteLine("----------------------");
                                Console.WriteLine("1 para intentar hacer la transferencia");
                                Console.WriteLine("2 para seguir gestionando tu cuenta");
                                Console.WriteLine("3 para terminar la operaciones y salir");
                                sSecondChance = Console.ReadLine();
                            }
                            if (sSecondChance == "2")
                            {
                                MenuOption3(); //Entra otra vez en el menú general de gestionar cuenta
                            }
                            if (sSecondChance == "1")
                            {//vuelve a intentar la transferencia
                               makeTransfer();                            
                            }
                            if (sSecondChance == "3")
                            {//finaliza las operaciones y se termina el programa
                                setFinalise(true);
                                Console.WriteLine("Has termiando las operaciones y has salido");
                            }
                        }
                    }else{//La cantidad que quiere transferir es menor a lo que tiene en la cuenta a si que puede seguir con el proceso   
                        iGetMoneyeDestinatary += iTransAmount;
                        iGetMoneyOrigin -= iTransAmount;
                        string i = iTransAmount.ToString();
                        //introduzco el dinero de las transferencias
                        db.ActualizarCampo(sDestinataryTransfer,"CurrentMoney",iGetMoneyeDestinatary);//al destinatario
                        db.ActualizarCampo(clientName,"CurrentMoney", iGetMoneyOrigin);//el origen
                        bTrans.addListMovements("Se ha transferido " + i + " euros de " + clientName + " a " + sDestinataryTransfer);
                        Console.WriteLine("La transferencia se ha realizado correctamente.");
                        gestionarSalir();
                    }
                }
            }
        }
    }
}