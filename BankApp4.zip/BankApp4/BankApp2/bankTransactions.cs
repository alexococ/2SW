namespace bankApp{
    public class bankTransactions{

        private float AmountTransaction{ get; set;}
        private string [] listMovements { get; set;}

        private List<string> transactions = new List<string>();

        //Constructor
       
        //Método get
        public float getAmountTransaction(){//Da la cantidad de la transación
            return AmountTransaction;
        }

        public string [] getInfoTransactions(){// Da la lista de los últimos moviemientos
            return listMovements;
        }

    public string getLastTransaction(){// Da la lista de los últimos moviemientos
            return transactions.Last();
        }

        public string getTransactionByPosition(int position) {
            if (transactions.Count <= position) return " ";

            return transactions[position];
        }

        //Método set 

        public void addListMovements(string movement){//Acumula los últimos movimientos
            transactions.Add(movement);
        }
    }
}