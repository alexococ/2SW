using System;
using System.Data;
using Microsoft.Data.Sqlite;

public class Database
{
    private string connectionString;

    // Constructor que recibe la ruta del archivo de la base de datos
    public Database(string dbFilePath)
    {
        connectionString = $"Data Source={dbFilePath}";
    }

    // Método para crear una tabla en la base de datos
   public void CrearTablaConDatos(string sNombre, string sAdress, string sPhone, int money)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection;

                // Define la consulta SQL para crear la tabla
                command.CommandText = "CREATE TABLE IF NOT EXISTS Personas (Name TEXT, Address TEXT, PhoneNumber TEXT, CurrentMoney REAL)";
                command.ExecuteNonQuery();

                // Después de crear la tabla, inserta datos en los campos
                command.CommandText = "INSERT INTO Personas (Name, Address, PhoneNumber, CurrentMoney) VALUES (@Name, @Address, @PhoneNumber, @CurrentMoney)";
                command.Parameters.AddWithValue("@Name", sNombre);
                command.Parameters.AddWithValue("@Address", sAdress);
                command.Parameters.AddWithValue("@PhoneNumber", sPhone);
                command.Parameters.AddWithValue("@CurrentMoney", money);
                command.ExecuteNonQuery();
            }

            connection.Close();
        }
    }

    // Método para actualizar un campo en la tabla
    public void ActualizarCampo(string nombre, string campo, object nuevoValor)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open(); // Abrir la conexión

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection; // Asignar la conexión al comando

                // Definir la consulta SQL para actualizar un campo
                command.CommandText = $"UPDATE Personas SET {campo} = $NuevoValor WHERE Name = $Nombre";
                command.Parameters.AddWithValue("$Nombre", nombre); // Parámetro para el nombre
                command.Parameters.AddWithValue("$NuevoValor", nuevoValor); // Parámetro para el nuevo valor

                command.ExecuteNonQuery(); // Ejecutar la consulta
            }

            connection.Close(); // Cerrar la conexión
        }
    }

    // Método para obtener el valor de un campo en la tabla
    public object ObtenerCampo(string nombre, string campo)
    {
        using (SqliteConnection connection = new SqliteConnection(connectionString))
        {
            connection.Open(); // Abrir la conexión

            using (SqliteCommand command = new SqliteCommand())
            {
                command.Connection = connection; // Asignar la conexión al comando

                // Definir la consulta SQL para obtener un campo
                command.CommandText = $"SELECT {campo} FROM Personas WHERE Name = $Nombre";
                command.Parameters.AddWithValue("$Nombre", nombre); // Parámetro para el nombre

                return command.ExecuteScalar(); // Ejecutar la consulta y devolver el resultado
            }
        }
    }
}