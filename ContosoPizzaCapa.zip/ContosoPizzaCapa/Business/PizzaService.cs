﻿using CostosoPizza.Models;
using CostosoPizza.Data;

namespace CostosoPizza.Services;

public static class PizzaService
{
    public static List<Pizza> GetAll() => PizzaRepository.GetAll();

    public static Pizza? Get(int id) => PizzaRepository.Get(id);

    public static void Add(Pizza pizza) => PizzaRepository.Add(pizza);

    public static void Delete(int id) => PizzaRepository.Delete(id);

    public static void Update(Pizza pizza) => PizzaRepository.Update(pizza);
}
