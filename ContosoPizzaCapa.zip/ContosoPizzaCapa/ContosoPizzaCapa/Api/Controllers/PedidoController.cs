using CostosoPizza.Models;
using CostosoPizza.Services;
using Microsoft.AspNetCore.Mvc;

namespace CostosoPizza.Controllers
{
    [ApiController]
    [Route("[controller]")]
    
    public class PedidoController : ControllerBase
    {

        [HttpGet("{id}")]
        public ActionResult<Pedido> Get(int id)
        {
            var pedido = PedidoService.Get(id);

            if (pedido == null)
                return NotFound();

            return pedido;
        }

        [HttpPost]

        public IActionResult Create(Pedido pedido)
        {
            if (pedido.Pizzas != null && pedido.Pizzas.Count > 0)
            {
                pedido.Precio = pedido.Pizzas.Sum(p => p.Price);
            }

            PedidoService.Add(pedido);
            return CreatedAtAction(nameof(Get), new { id = pedido.Id }, pedido);
        }

        
        [HttpPut("{id}/add-pizzas")]
        public IActionResult AddPizzas(int id, List<Pizza> pizzas)
        {
            PedidoService.AddPizzas(id, pizzas);
            return NoContent();


        }
    }
}