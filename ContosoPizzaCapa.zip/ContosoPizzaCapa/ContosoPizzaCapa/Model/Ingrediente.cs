namespace CostosoPizza.Models;
public class Ingrediente
{
    public int IngredienteId { get; set; }
    public string? Nombre { get; set; }
}
