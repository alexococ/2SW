using CostosoPizza.Models;
using CostosoPizza.Data;
using System.Collections.Generic;

namespace CostosoPizza.Services;

public static class PedidoService
{
     public static List<Pedido> GetAll() => PedidoRepository.GetAll();

        public static Pedido? GetPedido(int id) => PedidoRepository.Get(id);

        public static void Add(Pedido pedido) => PedidoRepository.Add(pedido);

        public static void Delete(int id) => PedidoRepository.Delete(id);

        public static Pedido? Get(int id) => PedidoRepository.Get(id);



    public static void AddPizzas(int pedidoId, List<Pizza> pizzas)
    {
        var pedido = PedidoRepository.Get(pedidoId);
        if (pedido != null)
        {
            pedido.Pizzas.AddRange(pizzas);
            pedido.Precio = pedido.Pizzas.Sum(p => p.Price);
            PedidoRepository.Update(pedido);
        }
    }
}