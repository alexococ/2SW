using CostosoPizza.Models;
using System.Collections.Generic;
using System.Linq;

namespace CostosoPizza.Data;

public class PedidoRepository
{
    private static List<Pedido> Pedidos { get; set; }
    private static int nextId = 1;

    static PedidoRepository()
    {
        Pedidos = new List<Pedido>();
    }

    public static List<Pedido> GetAll() => Pedidos;

    public static Pedido? Get(int id) => Pedidos.FirstOrDefault(p => p.Id == id);

    public static void Add(Pedido pedido)
    {
        pedido.Id = nextId++;
        Pedidos.Add(pedido);
    }

    public static void Delete(int id)
    {
        var pedido = Get(id);
        if (pedido is null)
            return;

        Pedidos.Remove(pedido);
    }

    public static void Update(Pedido pedido)
    {
        var index = Pedidos.FindIndex(p => p.Id == pedido.Id);
        if (index == -1)
            return;

        Pedidos[index] = pedido;
    }
}