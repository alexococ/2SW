document.addEventListener('DOMContentLoaded', function () {
    var anim = document.getElementById("animate");
    anim.onclick = function () {
        var path = document.getElementById('myPath');
        var length = path.getTotalLength();
        path.style.strokeDasharray = length;
        path.style.strokeDashoffset = length;
        path.classList.add('path-animation');
    }
});
