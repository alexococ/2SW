﻿namespace CostosoPizza.Service;

public class Class1
{

}
