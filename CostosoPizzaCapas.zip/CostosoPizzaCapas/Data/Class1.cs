﻿namespace CostosoPizza.Data;

public class Class1
{

}
