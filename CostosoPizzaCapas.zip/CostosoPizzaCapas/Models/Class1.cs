﻿namespace CostosoPizza.Model;

public class Class1
{

}
