function convertirSegundosAHMS(segundos) {
    const horas = Math.floor(segundos / 3600);
    const minutos = Math.floor((segundos % 3600) / 60);
    const segundosRestantes = segundos % 60;
    
    const tiempoFormateado = `${horas}:${minutos}:${segundosRestantes}`;
    
    console.log(`Tiempo: ${tiempoFormateado}`);
  }
  
  convertirSegundosAHMS(3665);
  convertirSegundosAHMS(4560);
  convertirSegundosAHMS(2250);