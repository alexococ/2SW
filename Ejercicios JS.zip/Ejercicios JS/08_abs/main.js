const assert = require('assert').strict;

function abs(value){
    let i = Math.abs(value)
    return i;
}

console.log(abs(-3))