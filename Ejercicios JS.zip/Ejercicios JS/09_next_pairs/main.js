const assert = require('assert').strict;

function imprimirParesContiguos(numero) {
    if (numero % 2 === 0) {
      for (let i = numero; i >= 0; i -= 2) {
        console.log(i);
      }
    } else {
      const numeroPar = numero - 1;
      
      for (let i = numeroPar; i >= 0; i -= 2) {
        console.log(i);
      }
    }
  }

imprimirParesContiguos(10); 