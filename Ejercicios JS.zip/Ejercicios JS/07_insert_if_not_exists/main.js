function insertIfNotExists(array, element, insertAtBeginning) {
    // Comprobar si el elemento no existe en el array
    if (!array.includes(element)) {
      // Si insertAtBeginning es true, insertar al principio
      if (insertAtBeginning) {
        array.unshift(element);
      } else {
        // Si no, insertar al final
        array.push(element);
      }
    }
    return array;
  }
  
  const frutas = ["pera", "manzana"];
  
  // Insertar "uva" al principio si no existe previamente
  insertIfNotExists(frutas, "pera", true);
  console.log(frutas); // Resultado: ["pera", "manzana"]
  
  // Insertar "manzana" al final si no existe previamente
  insertIfNotExists(frutas, "melon", false);
  console.log(frutas); // Resultado: [ "pera", "manzana", "melon"]
  
  // Insertar "kiwi" al final si no existe previamente
  insertIfNotExists(frutas, "melocoton", false);
  console.log(frutas); // Resultado: ["pera", "manzana", "melon", "melocoton"]