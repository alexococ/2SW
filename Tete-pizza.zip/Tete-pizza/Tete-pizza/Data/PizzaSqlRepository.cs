using System.Text.Json;
using System.Data.SqlClient;
using TetePizza.Models;
using System.Data;

namespace TetePizza.Data
{
    public class PizzaSqlRepository : PizzaRepository{
        private readonly string _connectionString;

        public PizzaSqlRepository(string connectionString)
        {
            _connectionString = connectionString;
        }





        public Pizza GetPizza()
        {
            var pizza = new Pizza(Id);

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var sqlString = "SELECT Number, Owner FROM BankAccounts WHERE Number=" + Id;
                var command = new SqlCommand(sqlString, connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Id = new Pizza
                        {
                            
                        };
                    }
                }
                
            }

            return pizza;
        }
        
    }
}
