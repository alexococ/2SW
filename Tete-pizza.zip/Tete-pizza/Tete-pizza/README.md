------------------------
- COMANDOS PARA DOCKER -
------------------------

* docker pull dvniiel/tetepizza

* docker run -p 8080:80 dvniiel/tetepizza


