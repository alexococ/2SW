namespace TetePizza.Model;

public class Ingredientes
{
    public int  idIngrediente { get; set; }
    public string  nombreIngrediente { get; set; }
    public string tipo { get; set; }
    public int cantidad { get; set; }
    public double precio { get; set; }
    public bool IsGlutenFree { get; set; }
}