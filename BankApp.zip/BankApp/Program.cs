﻿using System;
using System.Collections.Generic;
using System.Linq;
using Models;

User userAdmin = new User{
    Name = "Daniel",
    Lastname = "Valdovinos",
    NIF = "25361709T"
};

User user = new User{
    Name = "El",
    Lastname = "Pepe"
};


User userNull = new User{};

Console.WriteLine(user.ToString());
Console.WriteLine(userNull.ToString());


// Dictionary
var usersDict = new Dictionary<int, User>()
{
    {100, userAdmin}, {101, user}, {102, new User{
        Name = "Toñin",
        Lastname = "Coliseum",
        NIF = "usado"
    }}
};


Console.WriteLine(usersDict[102].Name);

try{
usersDict.Add(103, userAdmin); // NO REPETIR LA CLAVE -> HACK usersDict.Add(101, userAdmin);
usersDict.Add(102, user); // NO REPETIR LA CLAVE -> HACK usersDict.Add(101, userAdmin);
} catch (Exception)
{

}

foreach(var index in Enumerable.Range(100,4)){
    Console.WriteLine(usersDict[index].Name);
}


var bankaccountDict = new Dictionary<string, BankAccount>(){};




BankAccount bankAccount = new BankAccount("Daniel",100);
var tostring = bankAccount.ToString();
try {
    bankAccount.MakeDeposit(100,DateTime.Now,"Abrir cuenta");
} catch (Exception e) {
    Console.WriteLine(e.ToString());
}

bankaccountDict.Add(bankAccount.Number!, bankAccount);

try {
    bankAccount.MakeWithdrawal(100,DateTime.Now,"Pago alquiler");
} catch (ArgumentOutOfRangeException e) {
    Console.WriteLine(e.ToString());
} catch (InvalidOperationException e) {
    Console.WriteLine(e.ToString());
}



string history = bankAccount.GetAccountHistory();
Console.WriteLine(history); 


try {
    BankAccount bankacc = new BankAccount("Rubén",100);
    bankacc.MakeDeposit(100,DateTime.Now,"Propina");
    bankacc.MakeWithdrawal(100,DateTime.Now,"Pago seguro");
    bankacc.MakeWithdrawal(50,DateTime.Now,"Luz");
    Console.WriteLine(bankacc.GetAccountHistory()); 
} catch (ArgumentOutOfRangeException e) {
    Console.WriteLine("ArgumentOutOfRangeException: " + e.ToString());
} catch (InvalidOperationException e) {
    Console.WriteLine("InvalidOperationException: " + e.ToString());
}


InterestEarningAccount bankaccMarcos = new InterestEarningAccount("Marcos",1000);
bankaccMarcos.MakeDeposit(1000, DateTime.Now, "Cumpleaños");
bankaccMarcos.PerformMonthlyOperations(); // Simulo que han pasado 30 dias

Console.WriteLine(bankaccMarcos.GetAccountHistory());
