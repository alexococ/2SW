public class LineCreditAccount
{
    // Propiedades
    public string AccountNumber { get; set; }
    public decimal Balance { get; private set; }
    public decimal InterestRate { get; private set; }

    // Constructor
    public LineCreditAccount(string accountNumber, decimal initialBalance, decimal interestRate)
    {
        AccountNumber = accountNumber;
        Balance = initialBalance;
        InterestRate = interestRate;
    }

    // Método para calcular intereses y actualizar el saldo
    public void CalculateInterest()
    {
        decimal interestAmount = Balance * InterestRate;
        Balance += interestAmount;
    }

    // Método para hacer un depósito
    public void Deposit(decimal amount)
    {
        Balance += amount;
    }

    // Método para hacer un retiro
    public void Withdraw(decimal amount)
    {
        Balance -= amount;
    }
}
